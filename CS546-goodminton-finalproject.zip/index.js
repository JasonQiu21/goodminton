import * as playerFunctions from './players.js';
export const playerData = playerFunctions;